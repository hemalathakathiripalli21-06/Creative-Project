// routes/links.js
const express = require('express');
const router = express.Router();
const db = require('../db');
const { customAlphabet } = require('nanoid');
const validUrl = require('valid-url');

const CODE_LENGTH = parseInt(process.env.CODE_LENGTH || '7', 10);
const alphabet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const nanoid = customAlphabet(alphabet, CODE_LENGTH);

// POST /api/shorten
router.post('/shorten', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'Missing url in request body' });
    }
    // Validate URL
    if (!validUrl.isWebUri(url)) {
      return res.status(400).json({ error: 'Invalid URL' });
    }

    // Optionally check if URL already exists and return same code
    const existing = await db.query('SELECT code FROM links WHERE url = $1 LIMIT 1', [url]);
    if (existing.rows.length > 0) {
      const code = existing.rows[0].code;
      return res.json({ shortUrl: `${process.env.BASE_URL}/${code}`, code });
    }

    // Generate unique code — retry on collision (very unlikely)
    let code;
    for (let i = 0; i < 5; i++) {
      code = nanoid();
      try {
        await db.query('INSERT INTO links (code, url) VALUES ($1, $2)', [code, url]);
        break;
      } catch (err) {
        // if unique violation, loop to retry
        if (err.code !== '23505') { // 23505 = unique_violation
          throw err;
        }
      }
    }
    if (!code) {
      return res.status(500).json({ error: 'Failed to generate unique code' });
    }

    res.json({ shortUrl: `${process.env.BASE_URL}/${code}`, code });
  } catch (err) {
    console.error('Error /api/shorten', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/stats/:code
router.get('/stats/:code', async (req, res) => {
  const { code } = req.params;
  try {
    const result = await db.query('SELECT code, url, clicks, created_at FROM links WHERE code=$1', [code]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error /api/stats/:code', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
