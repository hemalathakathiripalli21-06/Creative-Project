// server.js
require('dotenv').config();
const express = require('express');
const path = require('path');
const linksRouter = require('./routes/links');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api', linksRouter);

// Redirect route: GET /:code
app.get('/:code', async (req, res) => {
  const code = req.params.code;
  try {
    const result = await db.query('SELECT url FROM links WHERE code = $1', [code]);
    if (result.rows.length === 0) {
      return res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
    }
    const url = result.rows[0].url;
    // increment click count (do not wait)
    db.query('UPDATE links SET clicks = clicks + 1 WHERE code = $1', [code]).catch(err => {
      console.error('Failed to increment clicks', err);
    });
    // redirect
    res.redirect(302, url);
  } catch (err) {
    console.error('Error redirecting', err);
    res.status(500).send('Server error');
  }
});

// Health check
app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
